package Parse;

interface Lexer {
    public Token nextToken() throws java.io.IOException;
}
