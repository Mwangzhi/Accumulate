// 通过的学员
const passedStudents = students.filter(x => x.score > 60)

// 组1的学员
const group1Students = students.filter(x => x.group_id === 1)
