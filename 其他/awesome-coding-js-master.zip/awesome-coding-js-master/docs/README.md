---
home: true
heroImage: ./logo.jpg
actionText: 开始阅读 →
actionLink: /dataStructure/
features:
- title: 数据结构专题
  details: 常见数据结构（二叉树、数组、堆、栈）的基本使用以及典型题目分析。
- title: 算法专题
  details: 常见算法解题指南和典型算法的JavaScript实现。
- title: JavaScript专题
  details: 常见JavaScript项目应用中的技巧，如节流防抖等。
footer: MIT Licensed | Copyright © 2019-present ConardLi
---